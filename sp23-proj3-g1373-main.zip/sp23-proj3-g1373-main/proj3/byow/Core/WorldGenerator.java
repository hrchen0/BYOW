package byow.Core;

import byow.TileEngine.TETile;
import byow.TileEngine.Tileset;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import java.awt.Point;
import java.awt.geom.Rectangle2D;
import java.util.HashSet;
import java.util.Set;

public class WorldGenerator {
    private final int width;
    private final int height;
    private final long seed;
    private final Random random;

    public WorldGenerator(int width, int height, long seed) {
        this.width = width;
        this.height = height;
        this.seed = seed;
        this.random = new Random(seed);
    }

    public TETile[][] generate() {
        TETile[][] world = new TETile[width][height];
        fillWithEmptyTiles(world);

        int numberOfRooms = random.nextInt(8) + 5;
        List<Room> rooms = new ArrayList<>();
        Set<Point> connectedPoints = new HashSet<>();

        while (rooms.size() < numberOfRooms) {
            int roomWidth = random.nextInt(15) + 4;
            int roomHeight = random.nextInt(15) + 4;
            int xPos = random.nextInt(width - roomWidth - 1);
            int yPos = random.nextInt(height - roomHeight - 1);

            Room room = new Room(xPos, yPos, roomWidth, roomHeight);
            if (!isRoomOverlapping(rooms, room)) {
                rooms.add(room);
                addRoom(world, room);
            }
        }

        for (int i = 0; i < rooms.size() - 1; i++) {
            Room room1 = rooms.get(i);
            Room room2 = rooms.get(i + 1);
            Point connection = connectRooms(world, room1, room2, connectedPoints);
            if (connection != null) {
                connectedPoints.add(connection);
            }
        }

        int numberOfPoles = random.nextInt(40) + 5; // Decide the number of poles you want to place
        placePoles(world, numberOfPoles); // Call the placePoles method

        placeFlowersAndGrass(world); // Call the placeFlowersAndGrass method
        return world;
    }
    public TETile[][] generateSimpleWorld() {
        // Generate the world with the same method as the `generate()` method.
        TETile[][] world = generate();

        // Add walls to the generated world.
        addWalls(world);

        // Place the avatar inside the walls.
        placeAvatar(world);

        return world;
    }

    private void addWalls(TETile[][] world) {
        // Add walls to the left and right edges of the world.
        for (int y = 0; y < world[0].length; y++) {
            world[0][y] = Tileset.WALL;
            world[world.length - 1][y] = Tileset.WALL;
        }

        // Add walls to the top and bottom edges of the world.
        for (int x = 0; x < world.length; x++) {
            world[x][0] = Tileset.WALL;
            world[x][world[0].length - 1] = Tileset.WALL;
        }
    }

    private void placeAvatar(TETile[][] world) {
        // Find a random floor tile to place the avatar.
        int x = 0;
        int y = 0;
        while (world[x][y] != Tileset.FLOOR) {
            x = random.nextInt(world.length);
            y = random.nextInt(world[0].length);
        }

        // Place the avatar.
        world[x][y] = Tileset.AVATAR;
    }

    private void fillWithEmptyTiles(TETile[][] world) {
        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                world[x][y] = Tileset.NOTHING;
            }
        }
    }
    private void placePoles(TETile[][] world, int numberOfPoles) {
        for (int i = 0; i < numberOfPoles; i++) {
            int x, y;
            do {
                x = random.nextInt(width);
                y = random.nextInt(height);
            } while (world[x][y] != Tileset.FLOOR || isPartOfHallway(world, x, y));

            world[x][y] = Tileset.POLE;
        }
    }
    private void placeFlowersAndGrass(TETile[][] world) {
        double flowerProbability = 0.05;
        double grassProbability = 0.3;

        for (int x = 0; x < width; x++) {
            for (int y = 0; y < height; y++) {
                if (world[x][y] == Tileset.FLOOR) {
                    double randomValue = random.nextDouble();
                    if (randomValue < flowerProbability) {
                        world[x][y] = Tileset.FLOWER;
                    } else if (randomValue < grassProbability) {
                        // Only place grass if it's not part of a hallway
                        if (!isPartOfHallway(world, x, y)) {
                            world[x][y] = Tileset.GRASS;
                        }
                    }
                }
            }
        }
    }
    private boolean isPartOfHallway(TETile[][] world, int x, int y) {
        int wallCount = 0;

        for (int xOffset = -1; xOffset <= 1; xOffset++) {
            for (int yOffset = -1; yOffset <= 1; yOffset++) {
                if (x + xOffset >= 0 && x + xOffset < width && y + yOffset >= 0 && y + yOffset < height) {
                    if (world[x + xOffset][y + yOffset] == Tileset.WALL) {
                        wallCount++;
                    }
                }
            }
        }

        return wallCount >= 5;
    }

    private void addRoom(TETile[][] world, Room room) {
        for (int x = room.xPos; x < room.xPos + room.width; x++) {
            for (int y = room.yPos; y < room.yPos + room.height; y++) {
                if (x == room.xPos || x == room.xPos + room.width - 1 || y == room.yPos || y == room.yPos + room.height - 1) {
                    world[x][y] = Tileset.WALL;
                } else {
                    world[x][y] = Tileset.FLOOR;
                }
            }
        }
    }

    private Point connectRooms(TETile[][] world, Room r1, Room r2, Set<Point> connectedPoints) {
        List<Point> r1Points = r1.getPerimeterPoints();
        List<Point> r2Points = r2.getPerimeterPoints();

        Point bestConnection = null;
        double minDistance = Double.MAX_VALUE;

        for (Point p1 : r1Points) {
            for (Point p2 : r2Points) {
                if (connectedPoints.contains(p1) || connectedPoints.contains(p2)) {
                    continue;
                }

                double distance = p1.distance(p2);
                if (distance < minDistance) {
                    bestConnection = new Point((p1.x + p2.x) / 2, (p1.y + p2.y) / 2);
                    minDistance = distance;
                }
            }
        }

        if (bestConnection != null) {
            createHallway(world, r1.getCenter(), r2.getCenter());
        }

        return bestConnection;
    }

    private boolean isRoomOverlapping(List<Room> rooms, Room newRoom) {
        Rectangle2D newRoomBounds = new Rectangle2D.Double(newRoom.xPos - 1, newRoom.yPos - 1, newRoom.width + 2, newRoom.height + 2);
        for (Room room : rooms) {
            Rectangle2D roomBounds = new Rectangle2D.Double(room.xPos - 1, room.yPos - 1, room.width + 2, room.height + 2);
            if (roomBounds.intersects(newRoomBounds)) {
                return true;
            }
        }
        return false;
    }

    private void createHallway(TETile[][] world, Point p1, Point p2) {
        int x1 = p1.x;
        int y1 = p1.y;
        int x2 = p2.x;
        int y2 = p2.y;

        int hallwayWidth = random.nextInt(2) + 1;

        if (random.nextBoolean()) {
            createHorizontalHallway(world, x1, x2, y1, hallwayWidth);
            createVerticalHallway(world, y1, y2, x2, hallwayWidth);
        } else {
            createVerticalHallway(world, y1, y2, x1, hallwayWidth);
            createHorizontalHallway(world, x1, x2, y2, hallwayWidth);
        }
    }


    private void createHorizontalHallway(TETile[][] world, int x1, int x2, int y, int width) {
        int startX = Math.min(x1, x2);
        int endX = Math.max(x1, x2);

        for (int x = startX; x <= endX; x++) {
            for (int yOffset = 0; yOffset < width; yOffset++) {
                world[x][y + yOffset] = Tileset.FLOOR;
                addWalls(world, x, y + yOffset);
            }
        }
    }

    private void createVerticalHallway(TETile[][] world, int y1, int y2, int x, int width) {
        int startY = Math.min(y1, y2);
        int endY = Math.max(y1, y2);

        for (int y = startY; y <= endY; y++) {
            for (int xOffset = 0; xOffset < width; xOffset++) {
                world[x + xOffset][y] = Tileset.FLOOR;
                addWalls(world, x + xOffset, y);
            }
        }
    }

    private void addWalls(TETile[][] world, int x, int y) {
        for (int xOffset = -1; xOffset <= 1; xOffset++) {
            for (int yOffset = -1; yOffset <= 1; yOffset++) {
                if (world[x + xOffset][y + yOffset] == Tileset.NOTHING) {
                    world[x + xOffset][y + yOffset] = Tileset.WALL;
                }
            }
        }
    }


    private static class Room {
        private final int xPos;
        private final int yPos;
        private final int width;
        private final int height;

        public Room(int xPos, int yPos, int width, int height) {
            this.xPos = xPos;
            this.yPos = yPos;
            this.width = width;
            this.height = height;

        }
        public List<Point> getPerimeterPoints() {
            List<Point> perimeterPoints = new ArrayList<>();
            for (int x = xPos; x < xPos + width; x++) {
                perimeterPoints.add(new Point(x, yPos));
                perimeterPoints.add(new Point(x, yPos + height - 1));
            }
            for (int y = yPos; y < yPos + height; y++) {
                perimeterPoints.add(new Point(xPos, y));
                perimeterPoints.add(new Point(xPos + width - 1, y));
            }
            return perimeterPoints;
        }

        public Point getCenter() {
            return new Point(getCenterX(), getCenterY());
        }



        public int getCenterX() {
            return xPos + width / 2;
        }

        public int getCenterY() {
            return yPos + height / 2;
        }
    }

}
