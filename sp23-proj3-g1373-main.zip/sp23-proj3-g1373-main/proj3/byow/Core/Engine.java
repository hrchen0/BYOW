package byow.Core;

import byow.TileEngine.TERenderer;
import byow.TileEngine.TETile;
import byow.TileEngine.Tileset;

import java.awt.*;
import java.io.File;
import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.OptionalLong;

import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.Stopwatch;

public class Engine {
    TERenderer ter = new TERenderer();
    public static final int WIDTH = 80;
    public static final int HEIGHT = 30;
    private static final int WAIT_TIME = 5000;
    private static final int WIN_SCORE = 50;
    private static final int MILLISECONDS_PER_SECOND = 1000;
    private static final int TITLE_FONT_SIZE = 32;
    private static final int OPTIONS_FONT_SIZE = 24;
    private static final int HUD_FONT_SIZE = 16;
    private static final long RANDOM_SEED = 12345L;
    private Point avatarPosition;
    private boolean quit = false;
    private StringBuilder inputString = new StringBuilder();

    // Additional instance variable to store the HUD text
    private String hudText = "";

    // Instance variable to store the current seed
    private StringBuilder currentSeed = new StringBuilder();

    // Additional instance variable to track if the user is entering a seed
    private boolean enteringSeed = false;

    // Instance variable to track the main menu state
    private boolean mainMenu = true;

    // Instance variable to keep track of the score
    private int score = 0;
    private static final int SIZE = 16;

    // Instance variable to keep track of the time of the last update
    private long lastUpdateTime = System.currentTimeMillis();

    // Instance variable to keep track of the time when the game started
    private long startTime;
    private static final int TIME_LIMIT = 40; // Fixed time limit of 30 seconds for all possible seed variations
    TETile tile = Tileset.FLOOR;
    String s = tile.description();

    public TETile[][] interactWithInputString(String input) {
        inputString.append(input);
        int len = input.length();
        int i = 0;
        OptionalLong seed = parseSeed(input);
        WorldGenerator worldGen;
        if (seed.isPresent()) {
            worldGen = new WorldGenerator(WIDTH, HEIGHT, seed.getAsLong());
        } else {
            worldGen = new WorldGenerator(WIDTH, HEIGHT, System.currentTimeMillis());
        }
        TETile[][] world = worldGen.generate();

        // Find a floor tile in the top left corner of the world
        outerLoop:
        for (int y = HEIGHT - 1; y >= 0; y--) {
            for (int x = 0; x < WIDTH; x++) {
                if (world[x][y] == Tileset.FLOOR) {
                    avatarPosition = new Point(x, y);
                    world[x][y] = Tileset.AVATAR;
                    break outerLoop;
                }
            }
        }

        while (i < len) {
            char c = input.charAt(i);
            if (c == ':') {
                saveWorld();
                break;
            } else if (c == 'W' || c == 'w') {
                moveAvatar(world, 0, 1);
            } else if (c == 'S' || c == 's') {
                moveAvatar(world, 0, -1);
            } else if (c == 'A' || c == 'a') {
                moveAvatar(world, -1, 0);
            } else if (c == 'D' || c == 'd') {
                moveAvatar(world, 1, 0);
            }
            i++;
        }

        return world;
    }

    private void moveAvatar(TETile[][] world, int dx, int dy) {
        int newX = avatarPosition.x + dx;
        int newY = avatarPosition.y + dy;
        if (newX < 0 || newX >= WIDTH || newY < 0 || newY >= HEIGHT) {
            // Don't allow the avatar to move off screen
            return;
        }
        TETile oldTile = world[avatarPosition.x][avatarPosition.y];
        TETile newTile = world[newX][newY];
        if (newTile == Tileset.GRASS) {
            score++;
        } else if (newTile == Tileset.FLOWER) {
            score += 2;
        }
        if (score >= WIN_SCORE) {
            drawMessage("You win!");
            saveWorld();
            quit = true;
        }
        if (newTile == Tileset.FLOOR
                || /* newTile == Tileset.POLE || */
                newTile == Tileset.GRASS || newTile == Tileset.FLOWER) {
            world[avatarPosition.x][avatarPosition.y] = Tileset.FLOOR;
            avatarPosition.setLocation(newX, newY);
            world[newX][newY] = Tileset.AVATAR;
            ter.renderFrame(world);
        }
    }

    public TETile[][] loadWorld() {
        File file = new File("save-file.txt");
        try {
            Scanner scanner = new Scanner(file);
            if (!scanner.hasNextLine()) {
                // No saved game found, generate a new world
                WorldGenerator worldGen = new WorldGenerator(WIDTH, HEIGHT, System.currentTimeMillis());
                return worldGen.generate();
            }
            String input = scanner.nextLine();
            return interactWithInputString(input);
        } catch (FileNotFoundException e) {
            // No saved game found, generate a new world
            WorldGenerator worldGen = new WorldGenerator(WIDTH, HEIGHT, System.currentTimeMillis());
            return worldGen.generate();
        }
    }

    public void saveWorld() {
        File file = new File("save-file.txt");
        try {
            PrintWriter writer = new PrintWriter(file);
            writer.print(inputString.toString());
            writer.close();
        } catch (FileNotFoundException e) {
            System.err.println("Failed to save the game.");
        }
    }

    private void drawMessage(String message) {
        // Set the font and color
        Font font = new Font("Monospaced", Font.BOLD, SIZE);
        StdDraw.setPenColor(StdDraw.WHITE);
        StdDraw.setFont(font);

        // Clear the screen
        StdDraw.clear(StdDraw.BLACK);

        // Draw the message
        StdDraw.text(WIDTH / 2.0, HEIGHT / 2.0, message);

        // Show the result
        StdDraw.show();

        // Wait for 5 seconds
        try {
            Thread.sleep(WAIT_TIME);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void moveToCompletedWorld() {
        WorldGenerator worldGenerator = new WorldGenerator(WIDTH, HEIGHT, RANDOM_SEED);
        TETile[][] simpleWorld = worldGenerator.generateSimpleWorld();
        ter.initialize(WIDTH, HEIGHT);

        // Find a floor tile in the top left corner of the world
        outerLoop:
        for (int y = HEIGHT - 1; y >= 0; y--) {
            for (int x = 0; x < WIDTH; x++) {
                if (simpleWorld[x][y] == Tileset.FLOOR) {
                    avatarPosition = new Point(x, y);
                    simpleWorld[x][y] = Tileset.AVATAR;
                    break outerLoop;
                }
            }
        }

        // Draw the initial state of the world
        ter.renderFrame(simpleWorld);

        // Set the font and color for the HUD
        Font font = new Font("Monospaced", Font.BOLD, HUD_FONT_SIZE);
        StdDraw.setPenColor(StdDraw.WHITE);
        StdDraw.setFont(font);

        // Start the game loop
        startTime = System.currentTimeMillis();
        while (!quit) {
            // Check if the time limit has been reached
            if (System.currentTimeMillis() - startTime >= TIME_LIMIT * MILLISECONDS_PER_SECOND) {
                drawMessage("Time's up!");
                saveWorld();
                quit = true;
            }

            // Check for user input
            if (StdDraw.hasNextKeyTyped()) {
                char key = StdDraw.nextKeyTyped();
                int dx = 0, dy = 0;
                switch (key) {
                    case 'w':
                    case 'W':
                        dy = 1;
                        break;
                    case 'a':
                    case 'A':
                        dx = -1;
                        break;
                    case 's':
                    case 'S':
                        dy = -1;
                        break;
                    case 'd':
                    case 'D':
                        dx = 1;
                        break;
                    default:
                        break;
                }
                moveAvatar(simpleWorld, dx, dy);
            }

            // Update the HUD
            long elapsedTime = (System.currentTimeMillis() - startTime) / MILLISECONDS_PER_SECOND;
            hudText = String.format("Score: %d     Time: %d/%d", score, elapsedTime, TIME_LIMIT);
            StdDraw.textLeft(1, HEIGHT - 1, hudText);

            // Render the updated frame
            ter.renderFrame(simpleWorld);

            // Sleep for a short time to avoid using too much CPU
            StdDraw.pause(10);
        }
    }
//Received some assistance from Chat GPT to write the interactwithKeyboard method below @ChatGPT
    public void interactWithKeyboard() {
        StdDraw.setCanvasSize(WIDTH * SIZE, HEIGHT * SIZE);
        StdDraw.setXscale(0, WIDTH);
        StdDraw.setYscale(0, HEIGHT);
        StdDraw.enableDoubleBuffering();
        int score = 0;
        Stopwatch timer = new Stopwatch();
        long startTime = System.currentTimeMillis();
        int timeLimit = TIME_LIMIT;
        while (mainMenu) {
            drawMainMenu();
            if (StdDraw.hasNextKeyTyped()) {
                char key = StdDraw.nextKeyTyped();
                switch (key) {
                    case 'n':
                    case 'N':
                        mainMenu = false;
                        enteringSeed = true;
                        break;
                    case 'l':
                    case 'L':
                        TETile[][] loadedWorld = loadWorld();
                        if (loadedWorld != null) {
                            ter.initialize(WIDTH, HEIGHT);
                            ter.renderFrame(loadedWorld);
                            if (avatarPosition != null && loadedWorld[avatarPosition.x][avatarPosition.y] != null) {
                                if (loadedWorld[avatarPosition.x][avatarPosition.y].equals(Tileset.FLOWER)) {
                                    score += 2;
                                } else if (loadedWorld[avatarPosition.x][avatarPosition.y].equals(Tileset.GRASS)) {
                                    score += 1;
                                }
                            }
                            mainMenu = false;
                        }
                        break;
                    case 'q':
                    case 'Q':
                        System.exit(0);
                        break;
                    default:
                        break; // add default case to avoid "switch without default clause" error
                }
            }
        }
        while (enteringSeed) {
            drawSeedInput();
            if (StdDraw.hasNextKeyTyped()) {
                char key = StdDraw.nextKeyTyped();
                if (Character.isDigit(key)) {
                    currentSeed.append(key);
                } else if ((key == 's' || key == 'S') && currentSeed.length() > 0) {
                    enteringSeed = false;
                    mainMenu = false;
                }
            }
        }
        drawMessage("You have 30 seconds to get 50 points. "
                +
                "Eating flowers is 2 points and eating grass is 1 point. Good luck!");
        TETile[][] world = interactWithInputString("N" + currentSeed.toString() + "S");
        ter.initialize(WIDTH, HEIGHT);
        ter.renderFrame(world);
        boolean waitForQ = false;
        while (!quit) {
            if (StdDraw.hasNextKeyTyped()) {
                char key = StdDraw.nextKeyTyped();
                int dx = 0, dy = 0;
                switch (key) {
                    case 'w':
                    case 'W':
                        dy = 1;
                        break;
                    case 'a':
                    case 'A':
                        dx = -1;
                        break;
                    case 's':
                    case 'S':
                        dy = -1;
                        break;
                    case 'd':
                    case 'D':
                        dx = 1;
                        break;
                    case ':':
                        waitForQ = true;
                        break;
                    case 'q':
                    case 'Q':
                        if (waitForQ) {
                            System.out.println("Quitting and saving...");
                            saveWorld();
                            quit = true;
                        }
                        break;
                    default:
                        waitForQ = false;
                }
                int newX = avatarPosition.x + dx;
                int newY = avatarPosition.y + dy;
                if (newX < 0 || newX >= WIDTH || newY < 0 || newY >= HEIGHT) {
                    // Don't allow the avatar to move off screen
                    continue;
                }
                TETile oldTile = world[avatarPosition.x][avatarPosition.y];
                TETile newTile = world[newX][newY];
                if (newTile == Tileset.GRASS) {
                    score++;
                } else if (newTile == Tileset.FLOWER) {
                    score += 2;
                }
                if (score >= WIN_SCORE) {
                    drawMessage("You win!");
                    saveWorld();
                    quit = true;
                }
                if (newTile == Tileset.FLOOR
                        || /* newTile == Tileset.POLE || */
                        newTile == Tileset.GRASS || newTile == Tileset.FLOWER) {
                    world[avatarPosition.x][avatarPosition.y] = Tileset.FLOOR;
                    avatarPosition.setLocation(newX, newY);
                    world[newX][newY] = Tileset.AVATAR;
                    ter.renderFrame(world);
                }
            }
            if (StdDraw.mouseX() >= 0 && StdDraw.mouseX()
                    <
                    WIDTH && StdDraw.mouseY() >= 0 && StdDraw.mouseY() < HEIGHT) {
                int x = (int) StdDraw.mouseX();
                int y = (int) StdDraw.mouseY();
                hudText = world[x][y].description();
            } else {
                hudText = "";
            }
            long currentTime = System.currentTimeMillis();
            int timeElapsed = (int) ((currentTime - startTime) / MILLISECONDS_PER_SECOND);
            int timeRemaining = timeLimit - timeElapsed;
            if (timeRemaining < 0) {
                timeRemaining = 0;
            }
            drawHUD(hudText + " Points: " + score + " Time: " + timeRemaining);
            StdDraw.show();
            if (timeRemaining <= 0) {
                drawMessage("Time's up!");
                saveWorld();
                quit = true;
            }
        }
        drawMessage("Your final score is " + score + ".");
        saveWorld();
        moveToCompletedWorld();
    }
    private void drawMainMenu() {
        StdDraw.clear(StdDraw.BLACK);
        Font titleFont = new Font("Monospaced", Font.BOLD, TITLE_FONT_SIZE);
        Font optionsFont = new Font("Monospaced", Font.PLAIN, OPTIONS_FONT_SIZE);
        StdDraw.setPenColor(StdDraw.WHITE);
        StdDraw.setFont(titleFont);
        StdDraw.text(WIDTH / 2.0, HEIGHT * 2 / 3.0, "CS61B: BYOW");
        StdDraw.setFont(optionsFont);
        StdDraw.text(WIDTH / 2.0, HEIGHT / 2.0, "New World (N)");
        StdDraw.text(WIDTH / 2.0, HEIGHT / 2.0 - 4, "Load (L)");
        StdDraw.text(WIDTH / 2.0, HEIGHT / 2.0 - 8, "Quit (Q)");
        StdDraw.show();
    }
    private void drawSeedInput() {
        StdDraw.clear(StdDraw.BLACK);
        Font promptFont = new Font("Monospaced", Font.PLAIN, OPTIONS_FONT_SIZE);
        StdDraw.setPenColor(StdDraw.WHITE);
        StdDraw.setFont(promptFont);
        StdDraw.text(WIDTH / 2.0, HEIGHT / 2.0, "Enter seed (Press 'S' to finish):");
        StdDraw.text(WIDTH / 2.0, HEIGHT / 2.0 - 4, currentSeed.toString());
        StdDraw.show();
    }
    private void drawHUD(String text) {
        // Set the font and color
        Font font = new Font("Monospaced", Font.BOLD, HUD_FONT_SIZE);
        StdDraw.setPenColor(StdDraw.WHITE);
        StdDraw.setFont(font);
        StdDraw.setPenColor(StdDraw.BLACK);
        StdDraw.filledRectangle(WIDTH / 2.0, HEIGHT - 1, WIDTH / 2.0, 1);
        StdDraw.setPenColor(StdDraw.WHITE);
        StdDraw.textLeft(1, HEIGHT - 1, text);
        long currentTime = System.currentTimeMillis();
        int timeElapsed = (int) ((currentTime - startTime) / MILLISECONDS_PER_SECOND);
        int timeRemaining = TIME_LIMIT - timeElapsed;
        if (timeRemaining < 0) {
            timeRemaining = 0;
        }
        StdDraw.text(WIDTH - 5, HEIGHT - 1, "Time left: " + timeRemaining + "s");
        StdDraw.setPenColor(StdDraw.BLACK);
    }
    class WorldPanel extends JPanel {
        private TETile[][] world;
        private JLabel hudLabel;
        private int tileSize;

        public WorldPanel(TETile[][] world, JLabel hudLabel, int tileSize) {
            this.world = world;
            this.hudLabel = hudLabel;
            this.tileSize = tileSize;
            setPreferredSize(new Dimension(world.length * tileSize, world[0].length * tileSize));

            addMouseMotionListener(new MouseAdapter() {
                @Override
                public void mouseMoved(MouseEvent e) {
                    int x = e.getX() / tileSize;
                    int y = e.getY() / tileSize;
                    if (x >= 0 && x < world.length && y >= 0 && y < world[0].length) {
                        hudLabel.setText(world[x][y].description());
                    } else {
                        hudLabel.setText("");
                    }
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.setFont(new Font("Monospaced", Font.PLAIN, tileSize));
            for (int x = 0; x < world.length; x++) {
                for (int y = 0; y < world[0].length; y++) {
                    String tileChar = Character.toString(world[x][y].character());
                    g.drawString(tileChar, x * tileSize, y * tileSize + tileSize);
                }
            }
        }
    }

    private OptionalLong parseSeed(String input) {
        StringBuilder seedBuilder = new StringBuilder();
        input = input.toUpperCase();
        boolean foundN = false;

        for (char c : input.toCharArray()) {
            if (c == 'N') {
                foundN = true;
                continue;
            }

            if (foundN) {
                if (c == 'S') {
                    break;
                }

                if (Character.isDigit(c)) {
                    seedBuilder.append(c);
                } else {
                    return OptionalLong.empty();
                }
            }
        }

        if (!foundN || seedBuilder.length() == 0) {
            return OptionalLong.empty();
        }

        return OptionalLong.of(Long.parseLong(seedBuilder.toString()));
    }

    public static void main(String[] args) {
        Engine engine = new Engine();
        TERenderer ter = new TERenderer();
        ter.initialize(WIDTH, HEIGHT);

        // Interact with the input string to get the initial state of the world
        TETile[][] world = engine.interactWithInputString("N12345S");
        ter.renderFrame(world);

        // Check if the user wants to load a saved game
        if (world == null) {
            // Load the saved game
            world = engine.loadWorld();
            if (world == null) {
                // No saved game found, exit the program
                return;
            }
        }

        engine.interactWithKeyboard(); // Use the new interactWithKeyboard method
    }
}
