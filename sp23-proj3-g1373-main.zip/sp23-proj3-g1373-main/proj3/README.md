# Build Your Own World Design Document

**Partner 1: Jack Swenson

**Partner 2: Haoran Chen

## Classes and Data Structures

## Algorithms

## Persistence
